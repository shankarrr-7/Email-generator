## Set-up
1. To get started we first need to get an API_KEY from here: https://aistudio.google.com/app/apikey . Click on 'create API Key'.
    Inside `.env` update the value of `GOOGLE_API_KEY` with the API_KEY you created. 


2. python -m venv venv
3. venv/scripts/activate.bat
4. To get started, first install the dependencies using:
    ```commandline
     pip install -r requirements.txt
    ```
5. After installing all the requirements, the install gradio by using the command line:
     pip install gradio
  
6. In another terminal:
     venv/scripts/activate.bat
     uvicorn app: upload_app --reload

7. Run the streamlit app in the first terminal:
   ```commandline
   streamlit run app.py
   ```